# hello-world-package/greet.py

def say_hello(name: str) -> str:
    return f"Hello, {name}!"
