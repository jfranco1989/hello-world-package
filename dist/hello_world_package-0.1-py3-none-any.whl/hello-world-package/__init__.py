# hello-world-package/__init__.py

from .greet import say_hello
